﻿/*
 * Domnique Canada
 * CST-250
 * Milestone 2
 * 03/08/2026
 */
using System;
using System.Collections.Generic;
using System.Text;

namespace MinesweeperClassLibrary.Models
{
    public class BoardModel
    {
        public int Size { get; set; }

        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }

        public CellModel[,] Cells { get; set; }

        public int Difficulty { get; set; }

        public int RewardsRemaining { get; set; }

        public GameState GameState { get; set; }

        public BoardModel(int size)
        {
            Size = size;
            Cells = new CellModel[size, size];

            for (int r = 0; r < size; r++)
            {
                for (int c = 0; c < size; c++)
                {
                    Cells[r, c] = new CellModel
                    {
                        Row = r,
                        Column = c
                    };
                }
            }
        }
    }
}

