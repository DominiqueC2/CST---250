﻿/*
 * Domnique Canada
 * CST-250
 * Milestone 2
 * 03/08/2026
 */
using System;
using System.Collections.Generic;
using System.Text;

namespace MinesweeperClassLibrary.Models
{
    public enum GameState
    {
        InProgress,
        Won,
        Lost
    }
}
