﻿
using MinesweeperClassLibrary.BusinessLogic;
using MinesweeperClassLibrary.Models;
using Xunit;

namespace MinesweeperTests
{
    public class BoardLogicTests
    {
        [Fact]
        public void SetupBombs_ShouldPlaceBombsOnBoard()
        {
            // Arrange
            BoardModel board = new BoardModel(10);
            BoardLogic logic = new BoardLogic();

            // Act
            logic.SetupBombs(board);

            // Count bombs
            int bombCount = 0;

            for (int r = 0; r < board.Size; r++)
            {
                for (int c = 0; c < board.Size; c++)
                {
                    if (board.Cells[r, c].IsBomb)
                        bombCount++;
                }
            }

            // Assert
            Assert.True(bombCount > 0);
        }

        [Fact]
        public void CountBombsNearby_ShouldCalculateNeighbors()
        {
            // Arrange
            BoardModel board = new BoardModel(3);
            BoardLogic logic = new BoardLogic();

            // Place a bomb manually
            board.Cells[1, 1].IsBomb = true;

            // Act
            logic.CountBombsNearby(board);

            // Assert
            Assert.Equal(1, board.Cells[0, 0].NumberOfBombNeighbors);
        }
    }
}
