﻿/*
 * Domnique Canada
 * CST-250
 * Milestone 2
 * 03/15/2026
 */

//ToDo-List
//loop to ask user if the row or col cell is already pick or another error
// fix numbers to go to 1-10 instead of 0-9
//


using MinesweeperClassLibrary.BusinessLogic;
using MinesweeperClassLibrary.Models;

namespace MinesweeperConsole
{
    internal class Program
    {
        static void Main(string[] args)
        {
            BoardLogic logic = new BoardLogic();
            BoardModel board = new BoardModel(10);

            logic.SetupBombs(board);
            logic.CountBombsNearby(board);

            bool victory = false;
            bool death = false;


            while (!victory && !death)
            {
                PrintBoard(board);

                Console.Write("Enter row: ");
                int row = int.Parse(Console.ReadLine());

                Console.Write("Enter column: ");
                int col = int.Parse(Console.ReadLine());

                Console.Write("Visit (V) or Flag (F): ");
                string action = Console.ReadLine().ToUpper();

                var cell = board.Cells[row, col];

                if (action == "V")
                {
                    logic.FloodFill(board, row, col);

                    if (cell.HasSpecialReward)
                    {
                        Console.WriteLine("Reward Found! You can peek at a cell.");

                        Console.Write("Peek Row: ");
                        int pr = int.Parse(Console.ReadLine());

                        Console.Write("Peek Column: ");
                        int pc = int.Parse(Console.ReadLine());

                        if (board.Cells[pr, pc].IsBomb)
                            Console.WriteLine("That cell contains a bomb!");
                        else
                            Console.WriteLine("Safe cell!");
                    }
                }

                if (action == "F")
                {
                    cell.IsFlagged = true;
                }

                var state = logic.DetermineGameState(board);

                if (state == GameState.Won)
                {
                    victory = true;
                }

                if (state == GameState.Lost)
                {
                    death = true;
                }
            }

            PrintBoard(board);

            if (victory)
                Console.WriteLine("You Win!");

            if (death)
                Console.WriteLine("You Hit a Bomb! Game Over!");
        }

        static void PrintBoard(BoardModel board)
        {
            Console.Write("   ");

            // Print the column
            for (int c = 0; c < board.Size; c++)
                Console.Write($"{c,3}");

            Console.WriteLine();

            // print the row
            for (int r = 0; r < board.Size; r++)
            {
                Console.Write($"{r,3}");

                for (int c = 0; c < board.Size; c++)
                {
                    var cell = board.Cells[r, c];

                    if (cell.IsFlagged)
                    {
                        Console.ForegroundColor = ConsoleColor.Cyan;
                        Console.Write("  F");
                    }
                    else if (!cell.IsVisited)
                    {
                        Console.ForegroundColor = ConsoleColor.Gray;
                        Console.Write("  ?");
                    }
                    else if (cell.IsBomb)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.Write("  B");
                    }
                    else if (cell.NumberOfBombNeighbors > 0)
                    {
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.Write($"  {cell.NumberOfBombNeighbors}");
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.DarkGray;
                        Console.Write("  .");
                    }
                }

                Console.WriteLine();
            }

            Console.ResetColor();
        }


    }
}