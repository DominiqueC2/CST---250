/*
 * Dominique Canada
 * CST-250
 * 03/07/2026
 * Chess Board Project
 * Activity 2
 */

using ChessBoardLibrary.Models;
using ChessBoardLibrary.Services.BusinessLogicLayer;

namespace ChessBoardGUIApp
{
    public partial class FrmChessBoard : Form
    {
        //Class level variables
        private BoardModel _board;
        private BoardLogic _boardLogic;
        // 2D array of buttons for the chess board
        private Button[,] _buttons;

        /// <summary>
        /// Default constructor for FrmChessBoard
        /// </summary>
        public FrmChessBoard()
        {
            InitializeComponent();

            // Initialize class level variables
            _board = new BoardModel(8);
            _boardLogic = new BoardLogic();
            _buttons = new Button[8, 8];   

            // Set up the panel with buttons
            SetUpButtons();
        }

        /// <summary>
        /// Populate the panel control with buttons
        /// </summary>
        private void SetUpButtons()
        {
            //
            //
            //
            int buttonSize = pnlChessBoard.Width / _board.Size;
            //Set the panel to be square
            pnlChessBoard.Height = pnlChessBoard.Width;
            // Use nested for loops to loop through the boards Grid
            for (int row = 0; row < _board.Size;  row++)
            {
                for (int col = 0; col < _board.Size; col++)
                {
                    // Set up each individual button
                    // Createw a new buttonin the 2D array
                    _buttons[row, col] = new Button();
                    //Get the current button
                    Button button = _buttons[row, col];
                    // Set the size for the button
                    button.Width = buttonSize;
                    button.Height = buttonSize;
                    // Set the location of the button
                    // Using the left and top sides
                    button.Left = row * buttonSize;
                    button.Top = col * buttonSize;
                    //Attach a click event handler to button
                    button.Click += BtnSquareClickEH;
                    //Store the location of the button in
                    // the Tag property using a Point cbject
                    button.Tag = new Point(row, col);
                    // Set the text for the button
                    button.Text = $"{row}, {col}";
                    //Add the button to the panels controls
                    pnlChessBoard.Controls.Add(_buttons[row, col]);
                }
            }

        }// End of the SetUpButtons method

        /// <summary>
        /// Click Event Handler for the chess board buttons
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnSquareClickEH(object sender, EventArgs e)
        {
            try
            {
                // Declare and initialize
                Button button = (Button)sender;
                Point point = (Point)button.Tag;
                int row = point.X;
                int col = point.Y;
                string piece = cmbChessPieces.Text;

                // Show the user their choice
                MessageBox.Show($"You clicked on row {row} and column {col}");

                // Send the board, current cell, and piece to the business logic layer
                _board = _boardLogic.MarkLegalMoves(_board, _board.Grid[row, col], piece);

                // Update the buttons
                UpdateButtons();
            }
            catch (Exception ex) 
            {
                MessageBox.Show("Something went wrong: " + ex.Message);
            }
        }

        /// <summary>
        /// Update the text for each button based on the board
        /// </summary>
        private void UpdateButtons()
        {
            // Declare and initialize
            string piece;

            // Set up a dictionary to get the names of the chess pieces
            Dictionary<string, string> pieceMap = new Dictionary<string, string>
    {
        { "N", "Knight" },
        { "R", "Rook" },
        { "B", "Bishop" },
        { "Q", "Queen" },
        { "K", "King" }
    };

            // Loop through each cell in the grid to update the corresponding button
            for (int row = 0; row < _board.Size; ++row)
            {
                for (int col = 0; col < _board.Size; col++)
                {
                    if (_board.Grid[row, col].PieceOccupyingCell != "")
                    {
                        // Use the dictionary to get the name of the chess piece
                        piece = pieceMap[_board.Grid[row, col].PieceOccupyingCell];

                        // Update the text for the button
                        _buttons[row, col].Text = piece;
                    }
                    else if (_board.Grid[row, col].IsLegalNextMove)
                    {
                        // Set the text to show a legal move
                        _buttons[row, col].Text = "Legal Move";
                    }
                    else
                    {
                        // Clear the text for any other buttons
                        _buttons[row, col].Text = "";
                    }
                }
            }
        }//End of the UpdateButtons method

        private void ApplyTheme()
        {
            Color color1 = Color.White;
            Color color2 = Color.Black;

            switch (cmbColorTheme.SelectedItem.ToString())
            {
                case "Classic":
                    color1 = Color.White;
                    color2 = Color.Black;
                    break;

                case "Cool":
                    color1 = Color.LightBlue;
                    color2 = Color.DarkBlue;
                    break;

                case "Warm":
                    color1 = Color.Orange;
                    color2 = Color.Red;
                    break;

                case "Neon":
                    color1 = Color.Lime;
                    color2 = Color.Magenta;
                    break;

                case "Pastel":
                    color1 = Color.LightPink;
                    color2 = Color.LightYellow;
                    break;
            }

            ColorBoard(color1, color2);
        }

        private void ColorBoard(Color color1, Color color2)
        {
            for (int row = 0; row < _board.Size; row++)
            {
                for (int col = 0; col < _board.Size; col++)
                {
                    if ((row + col) % 2 == 0)
                    {
                        _buttons[row, col].BackColor = color1;
                    }
                    else
                    {
                        _buttons[row, col].BackColor = color2;
                    }
                }
            }
        }

        private void cmbColorTheme_SelectedIndexChanged(object sender, EventArgs e)
        {
            ApplyTheme();
        }
    }
}
