﻿namespace ChessBoardGUIApp
{
    partial class FrmChessBoard
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            pnlChessBoard = new Panel();
            cmbChessPieces = new ComboBox();
            label3 = new Label();
            cmbColorTheme = new ComboBox();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(24, 25);
            label1.Name = "label1";
            label1.Size = new Size(394, 15);
            label1.TabIndex = 0;
            label1.Text = "Select a chess piece and its location on the board and see the legal moves";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(574, 25);
            label2.Name = "label2";
            label2.Size = new Size(43, 15);
            label2.TabIndex = 1;
            label2.Text = "Pieces:";
            // 
            // pnlChessBoard
            // 
            pnlChessBoard.Location = new Point(24, 56);
            pnlChessBoard.Name = "pnlChessBoard";
            pnlChessBoard.Size = new Size(500, 500);
            pnlChessBoard.TabIndex = 2;
            // 
            // cmbChessPieces
            // 
            cmbChessPieces.FormattingEnabled = true;
            cmbChessPieces.Items.AddRange(new object[] { "King", "Queen", "Bishop", "Knight", "Rook" });
            cmbChessPieces.Location = new Point(618, 22);
            cmbChessPieces.Name = "cmbChessPieces";
            cmbChessPieces.Size = new Size(121, 23);
            cmbChessPieces.TabIndex = 3;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(574, 173);
            label3.Name = "label3";
            label3.Size = new Size(79, 15);
            label3.TabIndex = 4;
            label3.Text = "Color Theme:";
            // 
            // cmbColorTheme
            // 
            cmbColorTheme.FormattingEnabled = true;
            cmbColorTheme.Items.AddRange(new object[] { "Classic", "Cool ", "Neon", "Pastel", "Warm" });
            cmbColorTheme.Location = new Point(659, 170);
            cmbColorTheme.Name = "cmbColorTheme";
            cmbColorTheme.Size = new Size(121, 23);
            cmbColorTheme.TabIndex = 5;
            cmbColorTheme.SelectedIndexChanged += cmbColorTheme_SelectedIndexChanged;
            // 
            // FrmChessBoard
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(816, 603);
            Controls.Add(cmbColorTheme);
            Controls.Add(label3);
            Controls.Add(cmbChessPieces);
            Controls.Add(pnlChessBoard);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "FrmChessBoard";
            Text = "Chess Board";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Panel pnlChessBoard;
        private ComboBox cmbChessPieces;
        private Label label3;
        private ComboBox cmbColorTheme;
    }
}
