﻿/*
 * Dominique Canada
 * Cst-250
 * 03/03/2026
 * Chess Board Project
 * Activity 2
 */
using ChessBoardLibrary.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace ChessBoardLibrary.Services.BusinessLogicLayer
{
    public  class BoardLogic
    {
        /// <summary>
        /// Reset the board by the setting the
        /// cell properties back to default
        /// Encapsulate this method so it can only be
        ///  called from this class.
        /// </summary>
        /// <param name="board"></param>
        /// <returns></returns>
        private BoardModel ResetBoard(BoardModel board)
        {
            //Use a foreach loop to iterate to their over every cell
            foreach(CellModel cell in board.Grid)
            {
                //Set the properties to their defaults
                cell.IsLegalNextMove = false;
                cell.PieceOccupyingCell = "";
            }
            // Return the board back to the presentation layer
            return board; 
        }

        /// <summary>
        /// Check if a row/column location is on the borad
        /// Encapsulate this method so it can only be
        ///  called from this class.
        /// </summary>
        /// <param name="board"></param>
        /// <param name="row"></param>
        /// <param name="col"></param>
        /// <returns></returns>
        private bool IsOnBoard(BoardModel board, int row, int col) 
        {
            // Get the size of the board
            int size = board.Size;
            //Check if the row is on the board
            bool IsRowSafe = row >= 0 && row < size;
            // Check if the column is on the board
            bool IsColumnSafe = col >= 0 && col < size;
            // Return true if both row and column are safe
            return IsRowSafe && IsColumnSafe;

        }

        /// <summary>
        /// Mark the legal moves for the given piece and location
        /// </summary>
        /// <param name="board"></param>
        /// <param name="currentCell"></param>
        /// <param name="chessPiece"></param>
        /// <returns></returns>
        public BoardModel MarkLegalMoves(BoardModel board, CellModel currentCell, string chessPiece)
        {
            // Reset the board
            board = ResetBoard(board);

            //Use a switch statement to determne the behavior of the piece
            switch (chessPiece.ToLower())
            {
                case "knight":
                    //Set the occupying protery for the current cell
                    board.Grid[currentCell.Row, currentCell.Column].PieceOccupyingCell = "N";
                    // MArk the valid moves for the knight
                    board = MarkValidKnightMoves(board, currentCell);
                    break;

                case "rook":
                    // Set the occupying property for the current cell
                    board.Grid[currentCell.Row, currentCell.Column].PieceOccupyingCell = "R";
                    // MArk the valid moves for the ROok
                    board = MarkValidRookMoves(board, currentCell);
                    break;

                case "bishop":
                    // Set the occupying property for the current cell
                    board.Grid[currentCell.Row, currentCell.Column].PieceOccupyingCell = "B";
                    // MArk the valid moves for the bishop
                    board = MarkValidBishopMoves(board, currentCell);
                    break;

                case "queen":
                    // Set the occupying property for the current cell
                    board.Grid[currentCell.Row, currentCell.Column].PieceOccupyingCell = "Q";
                    // MArk the valid moves for the queen
                    board = MarkValidQueenMoves(board, currentCell);
                    break;

                case "king":
                    // Set the occupying property for the current cell
                    board.Grid[currentCell.Row, currentCell.Column].PieceOccupyingCell = "K";
                    // MArk the valid moves for the ROok
                    board = MarkValidKingMoves(board, currentCell);
                    break;

                default:
                    //IF the piece is not valid, return the board as is
                    return board;
            }
            //Return the updated board
            return board;
        }//End of MarkLegalMoves method

        /// <summary>
        /// Mark the valid moves for the knight
        /// Acess modifier is private - meaning this method is encapsulated within the
        /// BoardLogic class and cannot be accessed
        ///directly outside the class        
        /// </summary>
        /// <param name="board"></param>
        /// <param name="currentCell"></param>
        /// <returns></returns>
        private BoardModel MarkValidKnightMoves(BoardModel board, CellModel currentCell)
        {
            // posssible moves for knight row
            int[] knightRowMoves = { 2, 1, -1, -2, -2, -1, 1, 2 };
            //possible moves for knight column
            int[] knightColMoves = { 1, 2, 2, 1, -1, -2, -2, -1 };
            // Loop through the the kinghts moves
            for (int i = 0; i < knightRowMoves.Length; i++)
            {
                //check if eaach move is on the board
                if (IsOnBoard(board, currentCell.Row + knightRowMoves[i], currentCell.Column + knightColMoves[i]))
                {
                    //If the cell is on the board, labelit as a possible move for the knight
                    board.Grid[currentCell.Row + knightRowMoves[i], currentCell.Column + knightColMoves[i]].IsLegalNextMove = true;
                }
            }
            return board;
        }


        private BoardModel MarkValidRookMoves(BoardModel board, CellModel currentCell) 
        {
            int[] rookRowMoves = {-1, 1, 0, 0};
            int[] rookColMoves = {0, 0, -1, 1};

            for (int i = 0; i < rookRowMoves.Length; i++)
            {
                int row = currentCell.Row + rookRowMoves[i];
                int col = currentCell.Column + rookColMoves[i];

                while (IsOnBoard(board, row, col))
                {  
                    board.Grid[row, col].IsLegalNextMove = true;

                    row += rookRowMoves[i];
                    col += rookColMoves[i];
                }
            }
            return board;
        }

        private BoardModel MarkValidBishopMoves(BoardModel board, CellModel currentCell) 
        {
            int[] bishopRowMoves = { -1, -1, 1, 1 };
            int[] bishopColMoves = { -1, 1, -1, 1 };

            for (int i = 0; i < bishopRowMoves.Length; i++)
            {
                int row = currentCell.Row + bishopRowMoves[i];
                int col = currentCell.Column + bishopColMoves[i];

                while (IsOnBoard(board, row, col))
                {
                    board.Grid[row, col].IsLegalNextMove = true;

                    row += bishopRowMoves[i];
                    col += bishopColMoves[i];
                }
            }
            return board;
        }

        private BoardModel MarkValidQueenMoves(BoardModel board, CellModel currentCell)
        {
            int[] queenRowMoves = { -1, -1, 1, 1, -1, 1, 0, 0 };
            int[] queenColMoves = { -1, 1, -1, 1, 0, 0, -1, 1 };

            for (int i = 0; i < queenRowMoves.Length; i++)
            {
                int row = currentCell.Row + queenRowMoves[i];
                int col = currentCell.Column + queenColMoves[i];

                while (IsOnBoard(board, row, col))
                {
                    board.Grid[row, col].IsLegalNextMove = true;

                    row += queenRowMoves[i];
                    col += queenColMoves[i];
                }
            }
            return board;
        }

        private BoardModel MarkValidKingMoves(BoardModel board, CellModel currentCell)
        {
            int[] kingRowMoves = { -1, -1, -1, 0, 0, 1, 1, 1 };
            int[] kingColMoves = { -1, 0, 1, -1, 1, -1, 0, 1 };

            for (int i = 0; i < kingRowMoves.Length; i++)
            {
                if (IsOnBoard(board, currentCell.Row + kingRowMoves[i], currentCell.Column + kingColMoves[i]))
                {
                    board.Grid[currentCell.Row + kingRowMoves[i], currentCell.Column + kingColMoves[i]].IsLegalNextMove = true;
                }
            }
            return board;
        }
    }
}
