﻿/*
 * Dominique Canada
 * Cst-250
 * 03/03/2026
 * Chess Board Project
 * Activity 2
 */
using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Text;

namespace ChessBoardLibrary.Models
{
    public class BoardModel
    {
        //Class level Properties
        // 'get' is public so other classes can read it 
        // 'private set' ensures only this class can modify it.
        //This is an example of encapsulation: internal details are hidden and controlled.
        public int Size {  get; private set; }
        public CellModel[,] Grid { get; private set; }

        /// <summary>
        /// Patameterized constructor for BoardModel
        /// </summary>
        /// <param name="size"></param>
        public BoardModel(int size)
        {
            // Initialize the prperties for the model
            Size = size;
            Grid = new CellModel[Size, Size];

            //Create the board
            InitializeBoard();
        }

        /// <summary>
        ///  Set up a new board
        ///  Encapsulat this helper method by making the access modifier private
        ///   So only the constructor can access this method
        /// </summary>
            private void InitializeBoard() 
        {
            //Loop through the rows of the grid
            for (int row = 0; row < Size; row++)
            {
                //Loop through thecloumns
                for (int col = 0; col < Size; col++)
                {
                    // Set each index to a new CelModel
                    // using the row and column
                    Grid[row, col] = new CellModel(row, col);
                }
            } 
        }
    }    
}

