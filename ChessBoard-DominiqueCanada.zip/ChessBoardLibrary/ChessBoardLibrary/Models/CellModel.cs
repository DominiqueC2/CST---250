﻿/*
 * Dominique Canada
 * Cst-250
 * 03/03/2026
 * Chess Board Project
 * Activity 2
 */
using System;
using System.Collections.Generic;
using System.Text;

namespace ChessBoardLibrary.Models
{
    public class CellModel
    {
        // Class level Properties with public getters andprivate setters
        //This is an example of encapsulation: external code can read the value
        //but only this class can modify them
        public int Row { get; private set; }
        public int Column { get; private set; }

        //These properties need to be readable and writeable from outside the model,
        //so we use public getters and setters. This is appropriate for properties
        //wher external components (e.g., the board logic) are responsible for updating them
        public string PieceOccupyingCell { get; set; }
        public bool IsLegalNextMove { get; set; }
    

        /// <summary>
        /// Patameterized constructor for cell model class
        /// </summary>
        /// <param name="row"></param>
        /// <param name="column"></param>
    public CellModel(int row, int column)
        {
            Row = row;
            Column = column;
            //Set default values for the other properties
            PieceOccupyingCell = "";
            IsLegalNextMove = false;
        }
    } 
}
