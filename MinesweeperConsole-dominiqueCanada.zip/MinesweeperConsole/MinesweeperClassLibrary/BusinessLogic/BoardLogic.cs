﻿/*
 * Domnique Canada
 * CST-250
 * Milestone 2
 * 03/15/2026
 */
using MinesweeperClassLibrary.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace MinesweeperClassLibrary.BusinessLogic
{
    public class BoardLogic
    {
        Random random = new Random();

        /// <summary>
        /// Set up randomly place bombs on the map
        /// </summary>
        /// <param name="board"></param>
        public void SetupBombs(BoardModel board)
        {
            Random random = new Random();

            int numberOfBombs = 0;

            // Set bombs based on difficulty
            if (board.Difficulty == 1) // Easy
                numberOfBombs = 10;
            else if (board.Difficulty == 2) // Medium
                numberOfBombs = 20;
            else if (board.Difficulty == 3) // Hard
                numberOfBombs = 40;

            int bombsPlaced = 0;

            // Place bombs (no duplicates)
            while (bombsPlaced < numberOfBombs)
            {
                int row = random.Next(board.Size);
                int col = random.Next(board.Size);

                if (!board.Cells[row, col].IsBomb)
                {
                    board.Cells[row, col].IsBomb = true;
                    bombsPlaced++;
                }
            }

            int rewardRow;
            int rewardCol;

            do
            {
                rewardRow = random.Next(board.Size);
                rewardCol = random.Next(board.Size);
            }
            while (board.Cells[rewardRow, rewardCol].IsBomb);

            board.Cells[rewardRow, rewardCol].HasSpecialReward = true;
        }//end

        //Check for bomds in the area
        public void CountBombsNearby(BoardModel board)
        {
            for (int r = 0; r < board.Size; r++)
            {
                for (int c = 0; c < board.Size; c++)
                {
                    int bombCount = 0;

                    for (int i = -1; i <= 1; i++)
                    {
                        for (int j = -1; j <= 1; j++)
                        {
                            int neighborRow = r + i;
                            int neighborCol = c + j;

                            if (neighborRow >= 0 && neighborRow < board.Size &&
                                neighborCol >= 0 && neighborCol < board.Size)
                            {
                                if (board.Cells[neighborRow, neighborCol].IsBomb)
                                {
                                    bombCount++;
                                }
                            }
                        }
                    }

                    if (board.Cells[r, c].IsBomb)
                    {
                        board.Cells[r, c].NumberOfBombNeighbors = 9;
                    }
                    else
                    {
                        board.Cells[r, c].NumberOfBombNeighbors = bombCount;
                    }
                }
            }
        }//end

        /// <summary>
        /// heck the current game state
        /// </summary>
        /// <param name="board"></param>
        /// <returns></returns>
        public GameState DetermineGameState(BoardModel board)
        {
            bool hasUnvisitedSafeCells = false;

            for (int r = 0; r < board.Size; r++)
            {
                for (int c = 0; c < board.Size; c++)
                {
                    var cell = board.Cells[r, c];

                    if (cell.IsVisited && cell.IsBomb)
                        return GameState.Lost;

                    if (!cell.IsBomb && !cell.IsVisited)
                        hasUnvisitedSafeCells = true;
                }
            }

            if (!hasUnvisitedSafeCells)
                return GameState.Won;

            return GameState.InProgress;
        }

        /// <summary>
        /// show the other empty slot when visted
        /// </summary>
        /// <param name="board"></param>
        /// <param name="row"></param>
        /// <param name="col"></param>
        public void FloodFill(BoardModel board, int row, int col)
        {
            // stop if out of bounds
            if (row < 0 || col < 0 || row >= board.Size || col >= board.Size)
                return;

            var cell = board.Cells[row, col];

            // stop if already visited or bomb
            if (cell.IsVisited || cell.IsBomb)
                return;

            // reveal cell
            cell.IsVisited = true;

            // stop if bombs exist
            if (cell.NumberOfBombNeighbors > 0)
                return;

            // recursive calls (8 directions)
            FloodFill(board, row - 1, col);     
            FloodFill(board, row + 1, col);     
            FloodFill(board, row, col - 1);     
            FloodFill(board, row, col + 1);     

            FloodFill(board, row - 1, col - 1);
            FloodFill(board, row - 1, col + 1);
            FloodFill(board, row + 1, col - 1);
            FloodFill(board, row + 1, col + 1);
        }
    }
}

