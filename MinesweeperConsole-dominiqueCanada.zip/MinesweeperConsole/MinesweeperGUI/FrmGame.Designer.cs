﻿namespace MinesweeperGUI
{
    partial class FrmGame
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            lblTimer = new Label();
            label3 = new Label();
            lblScore = new Label();
            panelBoard = new Panel();
            btnRestart = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(1091, 80);
            label1.Name = "label1";
            label1.Size = new Size(96, 23);
            label1.TabIndex = 0;
            label1.Text = "Start Time:";
            // 
            // lblTimer
            // 
            lblTimer.AutoSize = true;
            lblTimer.Location = new Point(1111, 122);
            lblTimer.Name = "lblTimer";
            lblTimer.Size = new Size(63, 23);
            lblTimer.TabIndex = 1;
            lblTimer.Text = "XX:XX";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(1121, 176);
            label3.Name = "label3";
            label3.Size = new Size(58, 23);
            label3.TabIndex = 2;
            label3.Text = "Score:";
            // 
            // lblScore
            // 
            lblScore.AutoSize = true;
            lblScore.Location = new Point(1140, 213);
            lblScore.Name = "lblScore";
            lblScore.Size = new Size(37, 23);
            lblScore.TabIndex = 3;
            lblScore.Text = "???";
            // 
            // panelBoard
            // 
            panelBoard.Location = new Point(0, 0);
            panelBoard.Name = "panelBoard";
            panelBoard.Size = new Size(1017, 868);
            panelBoard.TabIndex = 4;
            // 
            // btnRestart
            // 
            btnRestart.Location = new Point(1121, 279);
            btnRestart.Name = "btnRestart";
            btnRestart.Size = new Size(80, 35);
            btnRestart.TabIndex = 5;
            btnRestart.Text = "Restart";
            btnRestart.UseVisualStyleBackColor = true;
            btnRestart.Click += this.btnRestart_Click;
            // 
            // FrmGame
            // 
            AutoScaleDimensions = new SizeF(10F, 23F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1259, 937);
            Controls.Add(btnRestart);
            Controls.Add(panelBoard);
            Controls.Add(lblScore);
            Controls.Add(label3);
            Controls.Add(lblTimer);
            Controls.Add(label1);
            Font = new Font("Comic Sans MS", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Margin = new Padding(4, 5, 4, 5);
            Name = "FrmGame";
            Text = "Minesweeper";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label lblTimer;
        private Label label3;
        private Label lblScore;
        private Panel panelBoard;
        private Button btnRestart;
    }
}