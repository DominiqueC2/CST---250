﻿/*
 * Domnique Canada
 * CST-250
 * Milestone 2
 * 03/22/2026
 */
using MinesweeperClassLibrary.BusinessLogic;
using MinesweeperClassLibrary.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace MinesweeperGUI
{
    public partial class FrmGame : Form
    {
        //Class level Variables
        BoardModel board;
        BoardLogic logic;

        int boardSize;
        int difficulty;

        Button[,] buttons;

        DateTime startTime;
        string playerName;

        private System.Windows.Forms.Timer gameTimer;
        private int elapsedSeconds = 0;

        public FrmGame(int size, int difficultyLevel)
        {
            InitializeComponent();

            boardSize = size;
            difficulty = difficultyLevel;

            board = new BoardModel(boardSize);
            board.Difficulty = difficulty;


            //Timer
            startTime = DateTime.Now;
            // Initialize UI timer
            gameTimer = new System.Windows.Forms.Timer();
            gameTimer.Interval = 1000;
            gameTimer.Tick += GameTimer_Tick;
            gameTimer.Start();

            logic = new BoardLogic();


            logic.SetupBombs(board);
            logic.CountBombsNearby(board);

            CreateBoardUI();
            // Initialize labels
            lblScore.Text = "0";
            lblTimer.Text = "00:00";
        }

        /// <summary>
        /// Creates all the buttons on the screen
        /// </summary>
        private void CreateBoardUI()
        {
            buttons = new Button[boardSize, boardSize];

            int buttonSize = 40;

            for (int row = 0; row < boardSize; row++)
            {
                for (int col = 0; col < boardSize; col++)
                {
                    Button button = new Button();

                    button.Width = buttonSize;
                    button.Height = buttonSize;

                    button.Left = col * buttonSize;
                    button.Top = row * buttonSize;

                    button.Tag = new Point(row, col);

                    button.Click += Cell_Click;
                    button.MouseUp += Cell_RightClick;

                    panelBoard.Controls.Add(button);
                    buttons[row, col] = button;
                }
            }
        }// End of CreateBoardUI

        /// <summary>
        /// Runs when user clicks a button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Cell_Click(object sender, EventArgs e)
        {
            Button button = sender as Button;
            Point position = (Point)button.Tag;

            int row = position.X;
            int col = position.Y;

            var cell = board.Cells[row, col];

            if (cell.NumberOfBombNeighbors == 0 && !cell.IsBomb)
            {
                logic.FloodFill(board, row, col);
            }
            else
            {
                cell.IsVisited = true;
            }

            UpdateBoardUI();

            var gameState = logic.DetermineGameState(board);

            if (gameState == GameState.Lost)
            {
                // reveal bombs
                for (int r = 0; r < board.Size; r++)
                {
                    for (int c = 0; c < board.Size; c++)
                    {
                        if (board.Cells[r, c].IsBomb)
                        {
                            board.Cells[r, c].IsVisited = true;
                        }
                    }
                }

                UpdateBoardUI();

                TimeSpan timeTaken = DateTime.Now - startTime;
                int score = CalculateScore(timeTaken, false);

                lblScore.Text = score.ToString();

                // Ask name at end
                playerName = Microsoft.VisualBasic.Interaction.InputBox(
                    "Enter your name:",
                    "Game Over",
                    "Player");

                SaveGameResult(playerName, score, timeTaken);

                MessageBox.Show($"Game Over!\nScore: {score}\nTime: {timeTaken.TotalSeconds} sec");
            }
            else if (gameState == GameState.Won)
            {
                gameTimer.Stop();

                TimeSpan timeTaken = DateTime.Now - startTime;
                int score = CalculateScore(timeTaken, true);

                lblScore.Text = score.ToString();

                // Ask name at end
                playerName = Microsoft.VisualBasic.Interaction.InputBox(
                    "Enter your name:",
                    "You Win!",
                    "Player");

                SaveGameResult(playerName, score, timeTaken);

                MessageBox.Show($"You Win!\nScore: {score}\nTime: {timeTaken.TotalSeconds} sec");
            }
        }// End of Cell Click

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Cell_RightClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                Button button = sender as Button;
                Point position = (Point)button.Tag;

                int row = position.X;
                int col = position.Y;

                var cell = board.Cells[row, col];

                // Toggle flag
                cell.IsFlagged = !cell.IsFlagged;

                UpdateBoardUI();
            }
        }

        /// <summary>
        /// Updates what each button shows
        /// </summary>
        private void UpdateBoardUI()
        {
            for (int row = 0; row < boardSize; row++)
            {
                for (int col = 0; col < boardSize; col++)
                {
                    var cell = board.Cells[row, col];
                    var button = buttons[row, col];

                    if (!cell.IsVisited)
                    {
                        button.BackColor = Color.Gray;

                        if (cell.IsFlagged)
                        {
                            button.Text = "F";
                            button.ForeColor = Color.Blue;
                        }
                        else
                        {
                            button.Text = "";
                        }
                    }
                    else if (cell.IsBomb)
                    {
                        button.Text = "B";
                        button.BackColor = Color.Red;
                    }
                    else if (cell.NumberOfBombNeighbors > 0)
                    {
                        button.Text = cell.NumberOfBombNeighbors.ToString();
                    }
                    else
                    {
                        button.Text = "";
                    }
                }
            }
        }

        private int CalculateScore(TimeSpan timeTaken, bool won)
        {
            int baseScore = won ? 1000 : 100;

            int timePenalty = (int)timeTaken.TotalSeconds;

            int difficultyBonus = difficulty * 200;

            return baseScore + difficultyBonus - timePenalty;
        }



        private void SaveGameResult(string name, int score, TimeSpan timeTaken)
        {
            string filePath = "scores.txt";

            string line = $"{DateTime.Now}, {name}, Score: {score}, Time: {timeTaken.Seconds} sec";

            File.AppendAllText(filePath, line + Environment.NewLine);
        }

        private void GameTimer_Tick(object sender, EventArgs e)
        {
            elapsedSeconds++;

            TimeSpan time = TimeSpan.FromSeconds(elapsedSeconds);
            lblTimer.Text = time.ToString(@"mm\:ss");
        }

        /// <summary>
        /// Restart the game
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnRestart_Click(object sender, EventArgs e)
        {
            this.Hide();

            FrmDifficulty newGame = new FrmDifficulty();
            newGame.Show();

            this.Close();
        }
    }
}
