/*
 * Domnique Canada
 * CST-250
 * Milestone 2
 * 03/22/2026
 */


namespace MinesweeperGUI
{
    public partial class FrmDifficulty : Form
    {
        public FrmDifficulty()
        {
            InitializeComponent();
        }

        private void btnPlay_Click(object sender, EventArgs e)
        {
            int size = 8;
            int difficulty = 1;

            if (rbEasy.Checked)
            {
                size = 8;
                difficulty = 1;
            }
            else if (rbMedium.Checked)
            {
                size = 10;
                difficulty = 2;
            }
            else if (rbHard.Checked)
            {
                size = 15;
                difficulty = 3;
            }

            FrmGame gameForm = new FrmGame(size, difficulty);
            gameForm.Show();
            this.Hide();
        }
    }
}
