﻿namespace MinesweeperGUI
{
    partial class FrmDifficulty
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            grbDifficult = new GroupBox();
            rbHard = new RadioButton();
            rbMedium = new RadioButton();
            rbEasy = new RadioButton();
            btnPlay = new Button();
            grbDifficult.SuspendLayout();
            SuspendLayout();
            // 
            // grbDifficult
            // 
            grbDifficult.Controls.Add(rbHard);
            grbDifficult.Controls.Add(rbMedium);
            grbDifficult.Controls.Add(rbEasy);
            grbDifficult.Font = new Font("Comic Sans MS", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            grbDifficult.Location = new Point(22, 21);
            grbDifficult.Name = "grbDifficult";
            grbDifficult.Size = new Size(303, 234);
            grbDifficult.TabIndex = 0;
            grbDifficult.TabStop = false;
            grbDifficult.Text = "Choose a Level";
            // 
            // rbHard
            // 
            rbHard.AutoSize = true;
            rbHard.Font = new Font("Comic Sans MS", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            rbHard.Location = new Point(19, 166);
            rbHard.Name = "rbHard";
            rbHard.Size = new Size(65, 27);
            rbHard.TabIndex = 2;
            rbHard.TabStop = true;
            rbHard.Text = "Hard";
            rbHard.UseVisualStyleBackColor = true;
            // 
            // rbMedium
            // 
            rbMedium.AutoSize = true;
            rbMedium.Font = new Font("Comic Sans MS", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            rbMedium.Location = new Point(19, 114);
            rbMedium.Name = "rbMedium";
            rbMedium.Size = new Size(84, 27);
            rbMedium.TabIndex = 1;
            rbMedium.TabStop = true;
            rbMedium.Text = "Medium";
            rbMedium.UseVisualStyleBackColor = true;
            // 
            // rbEasy
            // 
            rbEasy.AutoSize = true;
            rbEasy.Font = new Font("Comic Sans MS", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            rbEasy.Location = new Point(22, 63);
            rbEasy.Name = "rbEasy";
            rbEasy.Size = new Size(62, 27);
            rbEasy.TabIndex = 0;
            rbEasy.TabStop = true;
            rbEasy.Text = "Easy";
            rbEasy.UseVisualStyleBackColor = true;
            // 
            // btnPlay
            // 
            btnPlay.Location = new Point(118, 275);
            btnPlay.Name = "btnPlay";
            btnPlay.Size = new Size(82, 29);
            btnPlay.TabIndex = 1;
            btnPlay.Text = "Play!";
            btnPlay.UseVisualStyleBackColor = true;
            btnPlay.Click += btnPlay_Click;
            // 
            // FrmDifficulty
            // 
            AutoScaleDimensions = new SizeF(10F, 23F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(353, 344);
            Controls.Add(btnPlay);
            Controls.Add(grbDifficult);
            Font = new Font("Comic Sans MS", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Margin = new Padding(4, 5, 4, 5);
            Name = "FrmDifficulty";
            Text = "Start a New Game";
            grbDifficult.ResumeLayout(false);
            grbDifficult.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox grbDifficult;
        private Button btnPlay;
        private RadioButton rbHard;
        private RadioButton rbMedium;
        private RadioButton rbEasy;
    }
}
